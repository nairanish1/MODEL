import os
import sys
print("Python executable:", sys.executable)
print("sys.path:", sys.path)
sys.path.append('/Users/anishnair/Global_HRTF_VAE/Holographic-VAE/')

import torch
import torch.nn as nn
import torch.nn.functional as F
import e3nn.o3 as o3
from typing import Dict, Tuple, Callable, Optional, List

# Import modules from your codebase.
from holographic_vae.nn.linearity import SO3_linearity
from holographic_vae.nn.nonlinearity import TP_nonlinearity
from holographic_vae.nn.normalization import batch_norm
from holographic_vae.so3.functional import make_dict
from holographic_vae.utils.orthonormalization import orthonormalize_frame
from holographic_vae.cg_coefficients.get_w3j_coefficients import get_w3j_coefficients
from holographic_vae.nn.blocks import CGBlock
expected_channels = {0: 8, 1: 14, 2: 19, 3: 22, 4: 24, 5: 24, 6: 23, 7: 20}

############################################
# 1) Validate Wigner 3j Matrices
############################################
def validate_w3j_matrices(w3j_matrices: Dict[Tuple[int, int, int], torch.Tensor], lmax: int):
    for l1 in range(lmax + 1):
        for l2 in range(lmax + 1):
            for l3 in range(abs(l1 - l2), min(l1 + l2, lmax) + 1):
                key = (l1, l2, l3)
                if key not in w3j_matrices:
                    raise ValueError(f"Missing Wigner 3j coefficient for (l1={l1}, l2={l2}, l3={l3}).")

def make_vec(sh_dict: Dict[int, torch.Tensor]) -> torch.Tensor:
    """Inverse of *sh_tensor_to_dict* – preserves order 0…7."""
    parts: List[torch.Tensor] = []
    for l in range(8):
        parts.append(sh_dict[l].squeeze(1))
    return torch.cat(parts, dim=1)

############################################
# 2) sh_tensor_to_dict
############################################
def sh_tensor_to_dict(sh: torch.Tensor, L: int = 7) -> Dict[int, torch.Tensor]:
    """[B,64] → {ℓ: [B,1,(2ℓ+1)]} with sanity check."""
    exp = (L + 1) ** 2
    if sh.size(1) != exp:
        raise ValueError(f"Expected {(L+1)**2} coeffs for L={L}, got {sh.size(1)}")
    out, idx = {}, 0
    for l in range(L + 1):
        n = 2 * l + 1
        out[l] = sh[:, idx : idx + n].unsqueeze(1)
        idx += n
    return out

############################################
# 3) Anthropometric Encoder (MLP)
############################################
class AnthropometricEncoder(nn.Module):
    def __init__(self, input_dim=25, hidden_dims=(64, 128, 64), output_dim=32):
        super().__init__()
        layers = []
        prev = input_dim
        for h in hidden_dims:
            layers.append(nn.Linear(prev, h))
            layers.append(nn.ReLU())
            prev = h
        layers.append(nn.Linear(prev, output_dim))
        self.mlp = nn.Sequential(*layers)
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.mlp(x)

############################################
# 4) FiLM Module (for conditioning)
############################################
class FiLM(nn.Module):
    def __init__(self, latent_dim: int, cond_dim: int):
        super().__init__()
        self.gamma = nn.Linear(cond_dim, latent_dim)
        self.beta = nn.Linear(cond_dim, latent_dim)

    def forward(self, z: torch.Tensor, cond: torch.Tensor) -> torch.Tensor:
        return z * self.gamma(cond) + self.beta(cond)

# ---------------------------------------------------------------------------
# Small wrappers to keep ℓ≤7 everywhere
# ---------------------------------------------------------------------------

def trim_L7(x: Dict[int, torch.Tensor]) -> Dict[int, torch.Tensor]:
    return {l: t for l, t in x.items() if l <= 7}


def assert_L7(x: Dict[int, torch.Tensor]):
    assert all(l <= 7 for l in x), f"High‑order comps: {[l for l in x]}"


# ---------------------------------------------------------------------------
# CGBlock factory capped at ℓ ≤ 7
# ---------------------------------------------------------------------------
from holographic_vae.nn.blocks import CGBlock

def cgblock_L7(irreps_in: o3.Irreps, mult: int, *, w3j):
    hidden = o3.Irreps("+".join(f"{mult}x{l}e" for l in range(8)))
    return CGBlock(
        irreps_in        = irreps_in,
        irreps_hidden    = hidden,
        w3j_matrices     = w3j,
        ch_nonlin_rule   = "full",
        ls_nonlin_rule   = "full",
        filter_symmetric = True,
        use_batch_norm   = False,
        norm_type        = "layer",
        normalization    = "component",
        norm_affine      = True,
        norm_nonlinearity= "swish",
    )

# ---------------------------------------------------------------------------
# Encoder – 3 × CGBlock   (1‑mult → 4‑mult → 4‑mult)
# ---------------------------------------------------------------------------
class EncoderSO3(nn.Module):
    def __init__(self, w3j, mult: int = 6):
        super().__init__()
        self.blocks = nn.ModuleList()

        # first block: input multiplicity 1 (matches raw SH vector)
        ir_in = o3.Irreps("+".join("1x{}e".format(l) for l in range(8)))
        for _ in range(3):
            blk = cgblock_L7(ir_in, mult, w3j=w3j)
            self.blocks.append(blk)
            ir_in = blk.irreps_out.simplify()  # feed into next block

    def forward(self, x: Dict[int, torch.Tensor]) -> Dict[int, torch.Tensor]:
        h = x
        for blk in self.blocks:
            h = trim_L7(blk(h))
            assert_L7(h)
        # average over multiplicity (dimension 1)
        return {l: t.mean(dim=1, keepdim=True) for l, t in h.items()}

# ---------------------------------------------------------------------------
# Output compressor – learn one scalar per coefficient
# ---------------------------------------------------------------------------
class OutputCompressor(nn.Module):
    def __init__(self):
        super().__init__()
        self.linears = nn.ModuleDict({str(l): nn.Linear(1, 1, bias=False) for l in range(8)})

    def forward(self, x: Dict[int, torch.Tensor]) -> Dict[int, torch.Tensor]:
        return {l: self.linears[str(l)](t.transpose(1, 2)).transpose(1, 2) for l, t in x.items()}

# ---------------------------------------------------------------------------
# Conditioning modules
# ---------------------------------------------------------------------------
class FiLM(nn.Module):
    def __init__(self, latent_dim: int, cond_dim: int):
        super().__init__()
        self.gamma = nn.Linear(cond_dim, latent_dim)
        self.beta  = nn.Linear(cond_dim, latent_dim)

    def forward(self, z, c):
        return z * self.gamma(c) + self.beta(c)


class AnthropometricEncoder(nn.Module):
    def __init__(self, in_dim=25):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, 32), nn.ReLU(),
            nn.Linear(32, 32)
        )

    def forward(self, x):
        return self.mlp(x)

# ---------------------------------------------------------------------------
# Full network
# ---------------------------------------------------------------------------
class So3HyperCNNv2(nn.Module):
    def __init__(self, w3j, num_freq_bins=512, latent_dim = 64, anthro_dim=25):
        super().__init__()
        self.enc  = EncoderSO3(w3j, mult=1)
        self.comp = OutputCompressor()
        self.to_z = nn.Linear(64, latent_dim)

        # FiLM conditioning
        self.cond  = AnthropometricEncoder(anthro_dim)
        self.f_emb = nn.Embedding(num_freq_bins, 8)
        self.d_emb = nn.Embedding(4, 4)
        self.film  = FiLM(latent_dim, 32 + 8 + 4)

        # decoder: two‑layer MLP
        self.dec = nn.Sequential(
            nn.Linear(latent_dim, 128), nn.ReLU(),
            nn.Linear(128, 64)
        )

    # --------------------------------------------------------------
    def forward(self, sh, head, ear, f_idx, d_idx):
        # SH → equivariant dict
        h = self.comp(self.enc(sh_tensor_to_dict(sh)))
        h_vec = make_vec(h)              # [B,64]

        z = self.to_z(h_vec)             # [B,latent]

        # conditioning
        c = torch.cat([
            self.cond(torch.cat([head, ear], 1)),
            self.f_emb(f_idx),
            self.d_emb(d_idx.long())
        ], 1)
        z = self.film(z, c)

        return self.dec(z)               # [B,64]
