

get_structural_info with pyrosetta may stall. It seems to infinitely loop on pdb 1NTH. It stalls either in "pose_from_pdb" or in "calculate_sasa" or "pose_coords_as_rows".

