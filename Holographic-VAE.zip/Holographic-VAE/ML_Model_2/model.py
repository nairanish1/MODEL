import os
import sys
print("Python executable:", sys.executable)
print("sys.path:", sys.path)
sys.path.append('/Users/anishnair/Global_HRTF_VAE/Holographic-VAE/')

import torch
import torch.nn as nn
import e3nn.o3 as o3
from typing import Dict, Tuple, List

# Import utility functions and blocks
from holographic_vae.so3.functional import make_dict
from holographic_vae.cg_coefficients.get_w3j_coefficients import get_w3j_coefficients
from holographic_vae.nn.blocks import CGBlock

############################################
# 1) sh_tensor_to_dict & make_vec
############################################
def sh_tensor_to_dict(sh: torch.Tensor, L: int = 7) -> Dict[int, torch.Tensor]:
    exp = (L + 1) ** 2
    if sh.size(1) != exp:
        raise ValueError(f"Expected {(L+1)**2} coeffs for L={L}, got {sh.size(1)}")
    out, idx = {}, 0
    for l in range(L + 1):
        n = 2 * l + 1
        out[l] = sh[:, idx : idx + n].unsqueeze(1)
        idx += n
    return out


def make_vec(sh_dict: Dict[int, torch.Tensor]) -> torch.Tensor:
    parts: List[torch.Tensor] = []
    for l in range(8):
        parts.append(sh_dict[l].squeeze(1))
    return torch.cat(parts, dim=1)

############################################
# 2) EncoderSO3 & OutputCompressor
############################################
class EncoderSO3(nn.Module):
    def __init__(self, w3j, mult: int = 1):
        super().__init__()
        self.blocks = nn.ModuleList()
        ir_in = o3.Irreps('+'.join(f"1x{l}e" for l in range(8)))
        for _ in range(3):
            blk = CGBlock(
                irreps_in=ir_in,
                irreps_hidden=o3.Irreps('+'.join(f"{mult}x{l}e" for l in range(8))),
                w3j_matrices=w3j,
                ch_nonlin_rule='full', ls_nonlin_rule='full',
                filter_symmetric=True,
                use_batch_norm=False,
                norm_type='layer', normalization='component',
                norm_affine=True, norm_nonlinearity='swish'
            )
            self.blocks.append(blk)
            ir_in = blk.irreps_out.simplify()

    def forward(self, x: Dict[int, torch.Tensor]) -> Dict[int, torch.Tensor]:
        h = x
        for blk in self.blocks:
            h = {l: t for l, t in blk(h).items() if l <= 7}
        # average over multiplicity dim=1
        return {l: t.mean(dim=1, keepdim=True) for l, t in h.items()}

class OutputCompressor(nn.Module):
    def __init__(self):
        super().__init__()
        self.linears = nn.ModuleDict({str(l): nn.Linear(1,1,bias=False) for l in range(8)})
    def forward(self, x: Dict[int, torch.Tensor]) -> Dict[int, torch.Tensor]:
        return {l: self.linears[str(l)](t.transpose(1,2)).transpose(1,2) for l,t in x.items()}

############################################
# 3) Anthropometric & Embedding
############################################
class AnthropometricEncoder(nn.Module):
    def __init__(self, in_dim=25):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, 24), nn.ReLU(),    # increased hidden size
            nn.Linear(24, 24)
        )
    def forward(self, x):
        return self.mlp(x)

############################################
# 4) Full network with adjusted dims
############################################
class So3HyperCNNv2(nn.Module):
    def __init__(self, w3j, num_freq_bins=512, latent_dim=48, anthro_dim=25):
        super().__init__()
        self.enc  = EncoderSO3(w3j, mult=1)
        self.comp = OutputCompressor()
        self.to_z = nn.Linear(64, latent_dim)

        # conditioning inputs
        self.cond  = AnthropometricEncoder(anthro_dim)
        self.f_emb = nn.Embedding(num_freq_bins, 6)    # adjusted emb dims
        self.d_emb = nn.Embedding(4, 3)
        cond_dim = 24 + 6 + 3

        # fusion MLP for concatenated [z; c]
        self.fusion_fc = nn.Sequential(
            nn.Linear(latent_dim + cond_dim, latent_dim),
            nn.ReLU()
        )

        # decoder: two-layer MLP
        self.dec = nn.Sequential(
            nn.Linear(latent_dim, 64), nn.ReLU(),
            nn.Linear(64, 64)
        )

    def forward(self, sh, head, ear, f_idx, d_idx):
        # SH → equivariant dict → vector
        h = self.comp(self.enc(sh_tensor_to_dict(sh)))
        h_vec = make_vec(h)              # [B,64]

        z = self.to_z(h_vec)             # [B,latent]

        # conditioning embeddings
        c = torch.cat([
            self.cond(torch.cat([head, ear],1)),
            self.f_emb(f_idx),
            self.d_emb(d_idx.long())
        ], 1)

        # simple fusion
        z = torch.cat([z, c], dim=1)     # [B, latent+cond]
        z = self.fusion_fc(z)            # [B,latent]

        return self.dec(z)               # [B,64]
